<!-- SCRIPTS -->
<script src="{{ asset('assets/js/modal.js') }}"></script>