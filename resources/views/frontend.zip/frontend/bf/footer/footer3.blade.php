<!-- END SCRIPTS -->
@yield('javascripts')

</body>

</html>