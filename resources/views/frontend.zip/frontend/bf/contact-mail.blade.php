<div>
    <h2>Hey !</h2> <br><br>

    Vous avez reçu un e-mail de : {{ $name }} <br><br>

    Détails de l'utilisateur: <br><br>

    Nom:  {{ $name }}<br>
    Email:  {{ $email }}<br>
    Objet:  {{ $subject }}<br>
    Message:  {{ $form_message }}<br><br>

    Merci
</div>
