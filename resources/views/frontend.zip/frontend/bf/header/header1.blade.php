<!-- CSS FILES -->
<link rel="stylesheet" href="{{ asset('assets/css/style.css')}}" />