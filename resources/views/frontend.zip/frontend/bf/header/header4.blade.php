<!-- ICONS -->
<link rel="stylesheet" href="{{ asset('assets/icons/fontawesome/css/all.min.css') }}" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lipis/flag-icons@6.6.6/css/flag-icons.min.css">